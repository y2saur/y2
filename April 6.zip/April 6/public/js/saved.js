/**SAVES AND NOTIFICATION JQUERY**/
$(document).ready(function()
{
    $('.list-group-item-action').click(function()
    {
    	window.location = "Post2" ; 
    });

    $('.notifbox').click(function()
    {
    	window.location = "Post" ; 
    });
});