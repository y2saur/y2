$(document).ready(function()
{
    $('.navbar-brand').click(function()
    {
    	window.location = "NewsFeed" ; 
    });

    $('#btn-Profile').click(function()
    {
    	window.location = "Profile" ; 
    });

    $('#btn-Home').click(function()
    {
    	window.location = "NewsFeed" ; 
    });

    $('#searchIcon').click(function()
    {
        window.location = "Search" ; 
    });

});