$(document).ready(function()
{
    $('#btn-postCard').on('click', '.btn-func', function()
    {
    	if($(this).attr('data-click-state') == 0)   
    	{
	        $(this).attr('data-click-state', 1);
	        $(this).css('background-color', '#00AF33') ;
      	}
      	else
      	{
      		$(this).attr('data-click-state', 0);
      		$(this).css('background-color','transparent') ;
      	}
    });

    $('#modalDelete').click(function()
    {
        window.location = "Profile" ;
    });

    $("#editPost").click(function()
    {
        window.location = "EditPost" ;
    });
});