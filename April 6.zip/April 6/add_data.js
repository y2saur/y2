// const express = require('express');
// const hbs = require('hbs');
// const path = require("path");
// const app = express();
const db = require('./models/db.js');

// db.createCollection("Posts");

var post = {
	postbyName 	: "yenwich",
	postTitle	: "This is one Post Title",
	content		: "This is the content of the post. I hope this pops up and it is correct.",
	image 		: [{
		img : "https://ewedit.files.wordpress.com/2018/06/switch_supersmashbrosultimate_scrn01_e3_bmp_jpgcopy.jpg"
	}],
	date		: "10-10-1010"
}

db.insertOne("Posts", post);

var post = {
	postbyName 	: "y2aquino",
	postTitle	: "This is one Post Title2",
	content		: "This is the content of the post. I hope this pops up and it is correct.",
	image 		: [{
	}],
	date		: "10-10-1010"
}

db.insertOne("Posts", post);

var post = {
	postbyName 	: "yenwich",
	postTitle	: "This is one Post Title3",
	content		: "This is the content of the post. I hope this pops up and it is correct.",
	image 		: [{
		img : "https://ewedit.files.wordpress.com/2018/06/switch_supersmashbrosultimate_scrn01_e3_bmp_jpgcopy.jpg"
	}],
	date		: "10-10-1010"
}

db.insertOne("Posts", post);

var post = {
	postbyName 	: "yenwich",
	postTitle	: "This is one Post Title4",
	content		: "This is the content of the post. I hope this pops up and it is correct.",
	image 		: [{
	}],
	date		: "10-10-1010"
}

db.insertOne("Posts", post);