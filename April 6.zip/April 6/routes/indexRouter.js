const express = require('express');
const router = express();
const controller = require('../controller/index');
const session = require("express-session");
const  bodyParser = require('body-parser');

const { uname } = session;

router.use(bodyParser());


router.get('/', controller.getLogIn);
router.get('/Login', controller.getLogIn);
router.get('/register', controller.getRegister);
router.post('/register', controller.postRegister);
router.post('/Login', controller.postLogIn);
router.get('/profile/:username', controller.getProfile);
router.get('/profile', controller.getProfile);
router.get('/Newsfeed', controller.getNewsfeed);
router.post('/Newsfeed', controller.postNewsfeed);
router.get("/Verify", controller.getVerify);

router.get('/SavedFollowed', controller.getSavedFollowed);


router.get('/Post', controller.getPost);
router.get('/Post2', controller.getPost2);
router.get('/Post3', controller.getPost3);
router.get('/editpost', controller.getEditPost);
router.get('/editprofile', controller.getEditProfile);
router.get('/notification', controller.getNotifications);
router.get('/postannouncement', controller.getPostAnnouncement);


router.get('/search', controller.getSearch);
router.get('/adminpage', controller.getAdminPage);
router.get('/banplayers', controller.getBanPlayers);


module.exports = router;